package com.wipro.validations;
import java.util.Random;
import com.wipro.bean.CabBean;
import com.wipro.userexceptions.*;
public class TripValidator
{
	public static String printBillAmount(CabBean cabbean)
	{
		String pk = null;
		if((cabbean.getBookingID().substring(0, 2).equals("AD"))&&(cabbean.getBookingID().length()==7)&&(Integer.parseInt(cabbean.getBookingID().substring(2, 7))>=0)&&(Integer.parseInt(cabbean.getBookingID().substring(2, 7))<=99999))
		{
			if((cabbean.getUserID()>=1001)&&(cabbean.getUserID()<=1500))
			{
				if(cabbean.getCabType().equals("Tata Indica")||(cabbean.getCabType().equals("Tata Indigo"))||(cabbean.getCabType().equals("BMU"))||(cabbean.getCabType().equals("Logan")))
				{
					if(Integer.parseInt(cabbean.getKmsUsed())>0)
					{
						int tk[]=new int[2];
						tk=amountGenerator(Integer.parseInt(cabbean.getKmsUsed()),cabbean.getCabType());
						pk="Total Amount : "+tk[1]+" , Receipt ID : "+tk[0];
					}
					else
					{
						NegativeKilometerException a=new NegativeKilometerException();
						pk=a.toString();
					}
				}
				else
				{
					pk="Invalid Cab Type";
				}
			}
			else
			{
				pk="Invalid User ID";
			}
		}
		else
		{
			pk="Invalid Booking ID";
		}
		return pk;
	}
	public static int[] amountGenerator(int kmsUsed, String cabType)
	{
		int k[]=new int[2];
		Random l=new Random();
		k[0]=l.nextInt(9000)+1000;
		if(cabType.equals("Tata Indica"))
		{
			k[1]=kmsUsed*12;
		}
		else if(cabType.equals("Tata Indigo"))
		{
			k[1]=kmsUsed*10;
		}
		else if(cabType.equals("BMU"))
		{
			k[1]=kmsUsed*45;
		}
		else
		{
			k[1]=kmsUsed*31;
		}
		return k;
	}
}