package com.wipro.userexceptions;

public class NegativeKilometerException
{
	public String toString()
	{
		return "Invalid KM";
	}
}